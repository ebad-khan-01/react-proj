const dummyData = [
    {
      id: 1,
      name: "John Doe",
      age: 25,
      image: "https://randomuser.me/api/portraits/men/1.jpg"
    },
    {
      id: 2,
      name: "Jane Smith",
      age: 30,
      image: "https://randomuser.me/api/portraits/women/2.jpg"
    },
    {
      id: 3,
      name: "Alice Johnson",
      age: 28,
      image: "https://randomuser.me/api/portraits/women/3.jpg"
    },
    {
      id: 4,
      name: "Bob Williams",
      age: 35,
      image: "https://randomuser.me/api/portraits/men/4.jpg"
    },
    {
      id: 5,
      name: "Charlie Brown",
      age: 22,
      image: "https://randomuser.me/api/portraits/men/5.jpg"
    }
  ];
  
  export default dummyData;
  